print(f"Welcome to tip calcultor")

total_bill=float(input(f"what was the total bill? : $"))
people=int(input(f"how many people to split the bill? :"))
tip_per=int(input(f"what is the tip percentage 10,12 or 15? :"))
tip=  (tip_per/100)*total_bill
final_bill= tip + total_bill

bill_per_person= final_bill/people

print(f"Each person should pay $ {bill_per_person}")