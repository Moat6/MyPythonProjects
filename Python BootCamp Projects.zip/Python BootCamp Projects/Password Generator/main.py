import random

print("WELCOME TO RANDOM PASSWORD GENERATOR\n")

website = input("Which Website Account is this? : ")
char_len = int(input("Enter no of Characters in password : "))
num_len = int(input("Enter no of Numbers in password : "))
sym_len = int(input("Enter no of Symbols in password : "))

alpha_list = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z".split(
  ',')
num_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
symbol_list = ['!', '@', '#', '%', '&', '*', '(', ')', '?']

pass_list = []
for i in range(char_len):
  pass_list.append(random.choice(alpha_list))
for i in range(num_len):
  pass_list.append(str(random.choice(num_list)))
for i in range(sym_len):
  pass_list.append(random.choice(symbol_list))

random.shuffle(pass_list)
pass_str = ""
for i in pass_list:
  pass_str += i

print("\n Generated Random password : ", pass_str)

