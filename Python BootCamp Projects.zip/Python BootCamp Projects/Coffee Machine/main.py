MENU = {
    "espresso": {
        "ingredients": {
            "water": 50,
            "coffee": 18,
        },
        "cost": 1.5,
    },
    "latte": {
        "ingredients": {
            "water": 200,
            "milk": 150,
            "coffee": 24,
        },
        "cost": 2.5,
    },
    "cappuccino": {
        "ingredients": {
            "water": 250,
            "milk": 100,
            "coffee": 24,
        },
        "cost": 3.0,
    }
}

resources = {
    "water": 300,
    "milk": 200,
    "coffee": 100,
}


money=0
is_on=True

def resource_check(choice):
    item=MENU[choice]["ingredients"]
    for ingr in item :
        if item[ingr]>resources[ingr] :
            print(f"Sorry there is not enough {ingr}.")
            return False
    return True

def coin_process(choice) :
    print("PLEASE INSERT COINS")
    #  quarters = $0.25, dimes = $0.10, nickles = $0.05, pennies = $0.01
    quarters=int(input("Quarters :")) *0.25
    dimes=int(input("Dimes :")) *0.10
    nickles=int(input("Nickels :")) *0.05
    pennies=int(input("Pennies :")) *0.01
    amount=round(quarters+dimes+nickles+pennies,2)
    cost=MENU[choice]["cost"]
    if amount<cost :
        print("Sorry that's not enough money. Money refunded.")
        return False
    else :
        global money
        money+= cost
        if amount>cost :
            change=amount-cost
            print(f"Here is ${change} dollars in change.")
            return True


def make_coffee(choice) :
    item=MENU[choice]["ingredients"]
    for ingr in item :
        resources[ingr] -= item[ingr]
    print(f"Here is your {choice} ☕️. Enjoy!")


print("\nWrite 'off' to Turn Off the Coffee Machine.\n  OR \nWrite 'report' to check Available Resources.\n")

while is_on :
    choice=input("What would you like? (espresso/latte/cappuccino):")

    if choice=="off" :
        is_on=False
    elif choice=="report":
        print("Water : ",resources["coffee"])
        print("Milk : ",resources["milk"])
        print("Coffee : ",resources["water"]) 
        print("Money : $",money)
    else :
        try :
            if resource_check(choice) :
                if coin_process(choice) :
                    make_coffee(choice)
        except KeyError :
            print("Please Write Correct Input. Restarting Machine.")
            
        
    

