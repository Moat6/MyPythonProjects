import turtle as t 
import time
from snake import Snake
from food import Food
from scoreboard import Scoreboard
# from walls import Walls

screen=t.Screen()
screen.setup(width=600,height=600)
screen.bgcolor("black")
screen.title("My Snake Game")
screen.tracer(0)

scoreboard=Scoreboard()
snake=Snake()
food=Food()
# walls=Walls()

screen.listen()
screen.onkey(snake.up,"Up")
screen.onkey(snake.down,"Down")
screen.onkey(snake.left,"Left")
screen.onkey(snake.right,"Right")


is_game_on=True
while is_game_on :
    screen.update()
    time.sleep(0.15)
    snake.move()
    # Collision With Food
    if snake.head.distance(food) < 15 :
        scoreboard.increase_score()
        scoreboard.write_score()
        snake.extend()
        food.refresh_food()
    
    # Collision With Wall
    if snake.head.xcor() > 290 or snake.head.xcor() < -290 or \
    snake.head.ycor() > 290 or snake.head.ycor() < -290 :
        is_game_on=False
        scoreboard.game_over()
    
    # Collision With Tail
    for seg in snake.segment[1:] :
        if snake.head.distance(seg.position()) < 10 :
            is_game_on=False
            scoreboard.game_over()
        


screen.exitonclick()