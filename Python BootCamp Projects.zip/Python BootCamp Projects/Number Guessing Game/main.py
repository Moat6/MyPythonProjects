import random,os

print("WELCOME TO NUMBER GUESSING GAME")

def game() :
    number=random.randint(1,100)
    level=input("Choose Difficulty Level (easy/hard) :").lower()
    if level=="easy" :
        attempts=10
    elif level=="hard" :
        attempts=5
    else :
        print("Please Write Correct Input,")
        game()
    while True :
        print(f"Number of attempts left : {attempts}")
        try :
            guess=int(input("Guess the Number :"))
        except (ValueError,NameError) :
            print("Please Write Correct Input.")
            print("Startimg The Game Again.")
            game()
        difference=number-guess
        if attempts==0 :
            print("YOU LOSE. TRY AGAIN")
            break
        if difference==0 :
            print(f"You Have Correctly Guessed The Number. You Win.")
            print()
            break
        elif -5<=difference<0  :
            print(f"High")
        elif difference<-5 :
            print("Very High")
        elif 0<difference<=5 :
            print(f"Low")
        elif difference>5 :
            print("Very Low")
        attempts -= 1

while True :
    play=input("Do You Want To Play The Gamme (y/n) :").lower()
    if play=="y" :
        os.system("cls")
        game()  
    else :
        break