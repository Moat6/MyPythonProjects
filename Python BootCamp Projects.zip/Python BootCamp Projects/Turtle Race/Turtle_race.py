import turtle as t
import random

colors=["pink","blue",'red',"green","orange","yellow","black"]
is_race_on=False
screen=t.Screen()
screen.setup(width=500,height=400)
user_bet=screen.textinput(title="Make A Bet",prompt="On which colored Turtle do you to bet on? ").lower()
turtle_list=[]


y=-90
for i in range(7):
    new_turtle=t.Turtle(shape="turtle")
    new_turtle.color(colors[i])
    new_turtle.penup()
    new_turtle.goto(-230,y)
    turtle_list.append(new_turtle)
    y += 30


if user_bet :
    is_race_on=True
while is_race_on :
    for turtle in turtle_list :
        random_move=random.randint(1,10)
        turtle.forward(random_move)
        if turtle.xcor()>=240 :
            winner=turtle.pencolor()
            is_race_on=False

print(f"Winner is {winner}")
if user_bet==winner :
    print("You Won the bet.")
else :
    print(f"You lose the bet")


screen.exitonclick()
