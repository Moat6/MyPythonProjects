from question_model import Question
from data import question_data
from quiz_brain import QuizBrain


question_bank=[]
for dict in question_data : 
    ques=dict["question"]
    ans=dict["correct_answer"]
    temp=Question(ques,ans)
    question_bank.append(temp)

quiz=QuizBrain(question_bank)

while quiz.still_has_questions() :
    quiz.next_question()
    
print("You HAve Completed The Quiz.")
print(f"Your FINAL SCORE is {quiz.score}/{quiz.question_num}")