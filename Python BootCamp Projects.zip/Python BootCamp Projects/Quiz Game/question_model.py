class Question :
    def __init__(self,q_text,a_text):
        self.text=q_text
        self.answer=a_text
