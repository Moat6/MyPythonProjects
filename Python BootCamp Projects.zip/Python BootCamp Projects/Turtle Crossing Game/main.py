import turtle as t
import time
from player import Player
from scoreboard import ScoreBoard
from cars import Cars

screen=t.Screen()
screen.setup(600,600)
screen.tracer(0)

player=Player()
cars=Cars()
scoreboard=ScoreBoard()

screen.listen()
screen.onkeypress(player.move_up,"Up")
screen.onkeypress(player.move_down,"Down")


game_is_on=True
while game_is_on:
    screen.update()
    time.sleep(0.1)
    cars.create_car()
    cars.move_car()

    # Collision with car
    for car in cars.car_list :
        if player.distance(car) < 20 :
            game_is_on=False
            scoreboard.game_over()

    # If player reaches at GOAL
    if player.ycor() > 290 :
        player.next_level()
        scoreboard.update_score()
        cars.increase_speed()

screen.exitonclick()