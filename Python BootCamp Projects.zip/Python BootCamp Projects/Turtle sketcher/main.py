import turtle as t

turtle=t.Turtle()
screen=t.Screen()

def forward() :
    turtle.forward(15)
def backward() :
    turtle.backward(15)
def left() :
    turtle.left(15)
def right() :
    turtle.right(15)
def clear() :
    turtle.reset()


t.listen()
t.onkeypress(fun=forward,key="Up")
t.onkeypress(fun=forward,key="w")
t.onkeypress(fun=backward,key="Down")
t.onkeypress(fun=backward,key="s")
t.onkeypress(fun=left,key="Left")
t.onkeypress(fun=left,key="a")
t.onkeypress(fun=right,key="Right")
t.onkeypress(fun=right,key="d")
t.onkeypress(fun=clear,key="c")

screen.exitonclick()
