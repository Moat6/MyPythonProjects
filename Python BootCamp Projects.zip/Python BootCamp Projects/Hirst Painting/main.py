# import colorgram

# colors=colorgram.extract("D:\PYTHON PROJECTS\Python BootCamp Projects\Hirst Painting\image.jpeg",35)

# color_list=[]
# for color in colors :
#     r=color.rgb.r
#     g=color.rgb.g
#     b=color.rgb.b
#     color_list.append((r,g,b))
# print(color_list)

import turtle as t
import random

turtle=t.Turtle()
t.colormode(255)
screen=t.Screen()
turtle.shape("circle")
turtle.pensize(30)
turtle.speed(0)

color_list=[(226, 231, 236), (58, 106, 148), (224, 200, 109), (134, 84, 58), (223, 138, 62), (196, 145, 171), \
            (234, 226, 204), (224, 234, 230), (141, 178, 204), (139, 82, 105), (209, 90, 69), (188, 80, 120), (68, 105, 90), \
            (237, 225, 233), (134, 182, 136), (133, 133, 74), (63, 156, 92), (48, 156, 194), (183, 192, 201), (214, 177, 191),\
            (19, 57, 93), (21, 68, 113), (112, 123, 149), (229, 174, 165), (172, 203, 182), (158, 205, 215), (69, 58, 47),\
            (108, 47, 60), (53, 70, 65), (72, 64, 53), (134, 42, 38), (47, 66, 61), (0, 122, 125)]

def left_to_right(color_list,x,y) :
    for side in range(15) :
        turtle.color(random.choice(color_list))
        turtle.penup()
        turtle.setpos(x,y)
        turtle.pendown()
        turtle.forward(0)
        x += 50

x=-350
y=-300
for up in range(13) :
    left_to_right(color_list,x,y)
    y += 50

screen.exitonclick()