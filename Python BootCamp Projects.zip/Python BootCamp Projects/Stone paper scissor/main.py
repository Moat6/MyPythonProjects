import random as r

def process(comp,user):
	c_score=u_score=dr=0
	if (comp==1 and user==1) or (comp==2 and user==2 ) or (comp==3 and user==3) :
		dr+=1
		print(" Draw match")
		pass
	elif (comp==1 and user==2) or (comp==2 and user==3) or (comp==3 and user==1) :
		print(" User Wins")
		u_score+=1
		
	elif (comp==1 and user==3) or (comp==2 and user==1) or (comp==3 and user==2) :
		print(" Computer Wins")
		c_score+=1
		
	return c_score, u_score,dr
		
def game():
	gg={1:"Stone",2:"Paper",3:"Scissor"}
	print("Enter: \n 1 for stone\n 2 for paper\n 3 for scissor")
	print()
	c_score=u_score=draw=0
	for i in range(10):
		print(" Round : ",i+1)
		user=int(input(" Enter your Move:"))
		if user not in gg:
			print("\n Please Enter a Valid Number")
			break
		print(" User Choice:",gg[user])
		comp=(r.randrange(1,4))
		print(" Computer Choice:",gg[comp])
		c,u,d=(process(comp,user))
		if c==1:
			c_score+=1
		elif u==1:
			u_score+=1
		else :
			draw+=1
		print()
	print()
	print(" Final Score of Computer:",c_score)
	print(" Final Score of User:",u_score)
	print("\tNumber of Draws:",draw)
	if c_score > u_score:
		print("\n\tCOMPUTER WINS")
	else:
		print("\n\tUSER WINS")
		
cnt=input("Do you wish to play?(y/n):")
if cnt in "yY":
	game()
else:
	pass

