import random
import hangart
from wordlist import word_list
lst=[]
stn=""
life=6
#word_list=["orange","apple","banana"]
word=[i for i in (random.choice(word_list).lower())]
w_len=len(word)
blank=["_"]*w_len

print(hangart.logo)

while True:
    print(f"WORD :: {stn.join(blank)}")
    guess=input("Guess the letter : ").lower()        
    for place in range(w_len) :
        if guess in lst :
            life += 1
            print(f"Word already guessed.")
            break
        if guess==word[place] :
            blank[place]=word[place]
    lst.append(guess)
    if guess not in stn.join(word)   :
        life -= 1
        print(f"Wrong Guess. Lives Left :{life}\n{hangart.stages[life]}")
    if life==0 :
        print(f"You loose. Word is {stn.join(word)}")
        break
    if blank==word :
        print(f"You Win. Word is {stn.join(word)}")
        break
