import random,art,os
from game_data import data


score=0
compare=random.choice(data)
def start() :
    def game(score,compare) :   
        against=random.choice(data)
        if compare==against :
            compare=random.choice(data)
        followerA=compare['follower_count']
        followerB=against['follower_count']
        print(f"Compare A: {compare['name']}, a {compare['description']}, from {compare['country']}. ")
        print(art.vs)
        print(f"Against B: {against['name']}, a {against['description']}, from {against['country']}. ")
        choice=input("Who has more followers? Type 'A' or 'B': ").lower()
        if choice=="a" :
            if followerA>followerB :
                score += 1
                print(f"\n You're right! Current score: {score}")
                compare=against
                game(score,compare)
            else :
                print(f"\n Sorry, that's wrong. Final score: {score}")
        elif choice=="b" :
            if followerA<followerB :
                score += 1
                print(f"\n You're right! Current score: {score}")
                compare=against
                game(score,compare)
            else :
                print(f"\n Sorry, that's wrong. Final score: {score}")
        else :
            print(f"\n Please Enter Correct Input. \n Staring The Game Again. \n\n")
            start()

    game(score,compare)


while True :
    play=input("Do You Want To Start The Game (y/n) :").lower()
    os.system("cls")
    if play=="y" :
        print(art.logo)
        start()
    else :
        print("BYE BYE !!")
        break