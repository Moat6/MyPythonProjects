from menu import Menu, MenuItem
from coffee_maker import CoffeeMaker
from money_machine import MoneyMachine

coffee_maker=CoffeeMaker()
money_machine=MoneyMachine()
menu=Menu()


is_on=True
while is_on :
    choice=input(f"What would you like? {menu.get_items()}:")
    coff=menu.find_drink(choice)
    if input=="off" :
        is_on= False
    elif input=="report" :
        coffee_maker.report()
        money_machine.report()
    else :
        if coffee_maker.is_resource_sufficient(coff) and money_machine.make_payment(coff.cost) :
            coffee_maker.make_coffee(coff)
            

