import turtle as t
import random,math

tom=t.Turtle()
t.colormode(255)
screen=t.Screen()
screen.screensize(600,600)
print(screen.canvheight,screen.canvwidth)
tom.shape("turtle")
tom.pensize(5)
tom.speed(0.1)
screen=t.Screen()

def colors() :
    r=random.randint(0,255)
    g=random.randint(0,255)
    b=random.randint(0,255)
    return (r,g,b)

while True :
    
    x=math.floor(round(tom.xcor()))
    y=math.floor(round(tom.ycor()))
    print(tom.position(),x,y)
    if x in (300,-300) or y in (300,-300) : 
        tom.pu()
        tom.setpos(0.00,0.00)
        tom.pd()
    tom.color(colors())
    tom.forward(30)
    tom.setheading(random.randrange(0,271,90))


